import React, { Component } from 'react'

export class show extends Component {
  render() {
    return (
      <div>show</div>
    )
  }
}

export default show